<?php
	$con= new mysqli('localhost','id13227590_root','karanYADAV22!','id13227590_quiz')or die("Could not connect to mysql".mysqli_error($con));
?>